__version__ = '0.3.0'

def cli():
    from stab import stab
