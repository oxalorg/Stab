__version__ = '1.0.0'

from stab import stab
cli = stab.cli
