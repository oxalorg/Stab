__version__ = '0.3.1'

def cli():
    from stab import stab
